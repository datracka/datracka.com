-- phpMyAdmin SQL Dump
-- version 2.11.9.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 13-03-2009 a las 12:17:56
-- Versión del servidor: 4.1.22
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `lagranev_lagranevasion`
--
CREATE DATABASE `lagranev_lagranevasion` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `lagranev_lagranevasion`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provincias`
--

CREATE TABLE IF NOT EXISTS `provincias` (
  `id_provincia` int(11) NOT NULL auto_increment,
  `id_comunidad` int(11) NOT NULL default '0',
  `provincia` varchar(32) NOT NULL default '',
  `provincia_abr` varchar(5) default NULL,
  PRIMARY KEY  (`id_provincia`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 PACK_KEYS=0 AUTO_INCREMENT=53 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ranking`
--

CREATE TABLE IF NOT EXISTS `ranking` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` text character set utf8,
  `email` varchar(75) collate latin1_general_ci NOT NULL default '',
  `puntuacion` int(11) NOT NULL default '0',
  `fecha` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=414 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` text collate latin1_general_ci,
  `email` text collate latin1_general_ci,
  `fecha` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=126 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuaris`
--

CREATE TABLE IF NOT EXISTS `usuaris` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(50) NOT NULL default '',
  `profesion` varchar(50) NOT NULL default '',
  `cp` varchar(5) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `telefono` varchar(25) NOT NULL default '',
  `direccion` varchar(50) NOT NULL default '',
  `foto` varchar(64) NOT NULL default '',
  `provincia` int(11) NOT NULL default '0',
  `edad` date NOT NULL default '0000-00-00',
  `p1` int(11) NOT NULL default '0',
  `p2` int(11) NOT NULL default '0',
  `p3` int(11) NOT NULL default '0',
  `p4` int(11) NOT NULL default '0',
  `p5` int(11) NOT NULL default '0',
  `pareja` int(11) NOT NULL default '0',
  `nombre_par` varchar(50) NOT NULL default '',
  `email_par` varchar(50) NOT NULL default '',
  `telefono_par` varchar(25) NOT NULL default '',
  `abierta1` text NOT NULL,
  `estado_auto` varchar(25) NOT NULL default '',
  `estado` varchar(25) NOT NULL default 'Pendiente',
  `puntuacion_auto` int(11) NOT NULL default '0',
  `puntuacion` int(11) NOT NULL default '0',
  `comentarios` text NOT NULL,
  `fecha_insercion` datetime NOT NULL default '0000-00-00 00:00:00',
  `fecha_ultim` datetime NOT NULL default '0000-00-00 00:00:00',
  `md5` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=798 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarisEnviaAmigo`
--

CREATE TABLE IF NOT EXISTS `usuarisEnviaAmigo` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(50) collate latin1_general_ci default NULL,
  `emails` text collate latin1_general_ci,
  `fecha` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=51 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarisInfo`
--

CREATE TABLE IF NOT EXISTS `usuarisInfo` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` text collate latin1_general_ci,
  `email` text collate latin1_general_ci,
  `fecha` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=210 ;
